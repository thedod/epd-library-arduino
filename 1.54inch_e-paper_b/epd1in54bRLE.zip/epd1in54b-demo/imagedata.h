extern const unsigned char coen[]; // only black
extern const unsigned char jazz_black[], jazz_red[];
extern const unsigned char dod_black[], dod_red[];
extern const unsigned char galei_black[], galei_red[];

extern const unsigned char raw_coen[]; // only black
extern const unsigned char raw_jazz_black[], raw_jazz_red[];
extern const unsigned char raw_dod_black[], raw_dod_red[];
extern const unsigned char raw_galei_black[], raw_galei_red[];

